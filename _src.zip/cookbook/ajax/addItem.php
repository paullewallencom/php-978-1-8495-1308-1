<?php 
if($_POST['type']=='Item'){
	echo 'New Item was added successfully.';
}
?>