﻿<?php 
if($_POST['username']==$_POST['password']){
	echo 'proceed';
}
?>